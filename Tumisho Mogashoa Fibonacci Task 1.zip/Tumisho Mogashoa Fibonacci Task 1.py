#Task 1: Generate infinite Fibonacci series 

def fibonacci():
    x, y = 0, 1          #Initialize x and y to 0 and 1 respectively
    while True:
        yield x          #Displays Current Value of X
        x, y = y, x + y  #Initializes updated values of x and y / x becomes old value of y / y becomes the sum of old values of x and y

# Accept input from the user

n = int(input("Enter the number of Fibonacci numbers you want to generate: "))

print("Number of first ",n," Fibonacci numbers:")

fib = fibonacci()

for _ in range(n):
    print(next(fib), end=" ") # generates next Fibonacci number everytime there is a function call
